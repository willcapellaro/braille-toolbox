# AstroType - Space Typing Adventure 🚀

A space-themed typing tutor game built with THREE.js that challenges players to type words appearing on a cosmic 3D orb.

## Features

- **3D Space Environment**: Beautiful cosmic setting with stars, nebula, and animated orb
- **Real-time Typing**: Live feedback as you type each word
- **Scoring System**: Points based on word length and typing accuracy
- **Lives System**: Challenge yourself with limited lives
- **WPM Tracking**: Monitor your typing speed improvement
- **Responsive Design**: Works on desktop and mobile devices

## Getting Started

### Prerequisites

- Node.js (version 16 or higher)
- npm or yarn package manager

### Installation

1. Clone or download this repository
2. Navigate to the project directory:
   ```bash
   cd astrotype-typing-game
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

### Development

Start the development server:
```bash
npm run dev
```

The game will open automatically in your browser at `http://localhost:3000`.

### Building for Production

Create a production build:
```bash
npm run build
```

Preview the production build:
```bash
npm run preview
```

## How to Play

1. **Start the Game**: Click "Start Game" on the welcome screen
2. **Type Words**: Type the words that appear on screen as quickly and accurately as possible
3. **Score Points**: Earn points for each correctly typed word (longer words = more points)
4. **Watch Your Lives**: You lose a life for each incorrect word
5. **Improve Your WPM**: Track your words-per-minute to see your progress

## Game Controls

- **Typing**: Use your keyboard to type the displayed words
- **Backspace**: Correct typing mistakes
- **Enter**: Submit the current word (optional - words auto-submit when complete)

## Technology Stack

- **THREE.js**: 3D graphics and animation
- **Vite**: Build tool and development server
- **HTML5/CSS3**: Modern web standards
- **Vanilla JavaScript**: ES6 modules and modern syntax

## Project Structure

```
astrotype-typing-game/
├── src/
│   ├── main.js          # Application entry point
│   └── game.js          # Main game logic and THREE.js scene
├── index.html           # HTML template
├── style.css            # Game styling and animations
├── vite.config.js       # Vite configuration
├── package.json         # Dependencies and scripts
└── README.md           # This file
```

## Customization

### Adding New Words

Edit the `words` array in `src/game.js` to add your own vocabulary:

```javascript
this.words = [
    'your', 'custom', 'words', 'here'
];
```

### Styling

Modify `style.css` to customize colors, fonts, and animations to match your preferences.

### Game Mechanics

Adjust game difficulty by modifying these values in `src/game.js`:
- Starting lives: Change `this.lives = 3`
- Scoring multiplier: Modify the scoring calculation in `correctWord()`
- Animation speeds: Adjust the rotation and animation values in `animate()`

## Browser Support

This game works in all modern browsers that support:
- WebGL (for THREE.js)
- ES6 Modules
- CSS3 animations

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is licensed under the MIT License - see the package.json file for details.

---

**Enjoy your space typing adventure!** 🌌✨