import * as THREE from 'three';

export class Game {
    constructor(container) {
        this.container = container;
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.orb = null;
        this.stars = [];
        this.nebula = null;
        
        // Game state
        this.gameState = 'start'; // 'start', 'playing', 'gameOver'
        this.score = 0;
        this.lives = 3;
        this.currentWord = '';
        this.typedWord = '';
        this.words = [
            'space', 'star', 'galaxy', 'planet', 'cosmic', 'nebula', 'orbit', 'meteor',
            'asteroid', 'comet', 'universe', 'solar', 'lunar', 'eclipse', 'gravity',
            'satellite', 'rocket', 'astronaut', 'telescope', 'constellation',
            'black hole', 'supernova', 'quasar', 'pulsar', 'wormhole', 'dark matter',
            'cosmic ray', 'light year', 'parallax', 'redshift', 'big bang',
            'milky way', 'andromeda', 'voyager', 'apollo', 'hubble', 'kepler'
        ];
        this.wordIndex = 0;
        this.wordsTyped = 0;
        this.startTime = null;
        this.bestWPM = 0;
        
        // Animation
        this.animationId = null;
        this.time = 0;
        
        this.init();
        this.setupEventListeners();
        this.showStartScreen();
    }
    
    init() {
        this.setupScene();
        this.createOrb();
        this.createStarField();
        this.createNebula();
        this.setupLighting();
        this.animate();
    }
    
    setupScene() {
        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x000011);
        
        // Camera
        this.camera = new THREE.PerspectiveCamera(
            75,
            window.innerWidth / window.innerHeight,
            0.1,
            1000
        );
        this.camera.position.z = 5;
        
        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.container.appendChild(this.renderer.domElement);
        
        // Handle resize
        window.addEventListener('resize', () => this.onWindowResize());
    }
    
    createOrb() {
        const geometry = new THREE.IcosahedronGeometry(1, 1);
        
        // Create a custom material with animated properties
        const material = new THREE.MeshPhongMaterial({
            color: 0x00ffff,
            emissive: 0x001133,
            shininess: 100,
            transparent: true,
            opacity: 0.8
        });
        
        this.orb = new THREE.Mesh(geometry, material);
        this.scene.add(this.orb);
        
        // Add wireframe overlay
        const wireGeometry = new THREE.IcosahedronGeometry(1.01, 1);
        const wireMaterial = new THREE.MeshBasicMaterial({
            color: 0x00ffff,
            wireframe: true,
            transparent: true,
            opacity: 0.3
        });
        
        const wireframe = new THREE.Mesh(wireGeometry, wireMaterial);
        this.scene.add(wireframe);
        this.wireframe = wireframe;
    }
    
    createStarField() {
        const starGeometry = new THREE.BufferGeometry();
        const starMaterial = new THREE.PointsMaterial({
            color: 0xffffff,
            size: 2,
            transparent: true,
            opacity: 0.8
        });
        
        const starVertices = [];
        
        for (let i = 0; i < 10000; i++) {
            const x = (Math.random() - 0.5) * 2000;
            const y = (Math.random() - 0.5) * 2000;
            const z = (Math.random() - 0.5) * 2000;
            
            starVertices.push(x, y, z);
        }
        
        starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
        
        this.stars = new THREE.Points(starGeometry, starMaterial);
        this.scene.add(this.stars);
    }
    
    createNebula() {
        const nebulaGeometry = new THREE.PlaneGeometry(50, 50);
        const nebulaMaterial = new THREE.MeshBasicMaterial({
            color: 0x4b0082,
            transparent: true,
            opacity: 0.1,
            side: THREE.DoubleSide
        });
        
        this.nebula = new THREE.Mesh(nebulaGeometry, nebulaMaterial);
        this.nebula.position.z = -20;
        this.scene.add(this.nebula);
    }
    
    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.2);
        this.scene.add(ambientLight);
        
        // Point light
        const pointLight = new THREE.PointLight(0x00ffff, 1, 100);
        pointLight.position.set(10, 10, 10);
        this.scene.add(pointLight);
        
        // Directional light
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(-1, 1, 1);
        this.scene.add(directionalLight);
    }
    
    setupEventListeners() {
        // Start game button
        document.getElementById('start-btn').addEventListener('click', () => {
            this.startGame();
        });
        
        // Restart game button
        document.getElementById('restart-btn').addEventListener('click', () => {
            this.restartGame();
        });
        
        // Keyboard input
        document.addEventListener('keydown', (event) => {
            if (this.gameState === 'playing') {
                this.handleKeyPress(event);
            }
        });
    }
    
    showStartScreen() {
        document.getElementById('start-screen').classList.remove('hidden');
        document.getElementById('game-over').classList.add('hidden');
    }
    
    startGame() {
        this.gameState = 'playing';
        this.score = 0;
        this.lives = 3;
        this.wordsTyped = 0;
        this.startTime = Date.now();
        this.bestWPM = 0;
        
        document.getElementById('start-screen').classList.add('hidden');
        this.nextWord();
        this.updateUI();
    }
    
    restartGame() {
        this.gameState = 'start';
        this.showStartScreen();
    }
    
    nextWord() {
        if (this.gameState !== 'playing') return;
        
        this.currentWord = this.words[Math.floor(Math.random() * this.words.length)];
        this.typedWord = '';
        this.updateWordDisplay();
    }
    
    handleKeyPress(event) {
        if (event.key === 'Backspace') {
            this.typedWord = this.typedWord.slice(0, -1);
        } else if (event.key === 'Enter') {
            this.submitWord();
        } else if (event.key.length === 1 && /[a-zA-Z\s]/.test(event.key)) {
            this.typedWord += event.key.toLowerCase();
        }
        
        this.updateWordDisplay();
        
        // Auto-submit when word is complete
        if (this.typedWord === this.currentWord) {
            setTimeout(() => this.submitWord(), 100);
        }
    }
    
    submitWord() {
        if (this.typedWord === this.currentWord) {
            this.correctWord();
        } else {
            this.incorrectWord();
        }
    }
    
    correctWord() {
        this.score += this.currentWord.length * 10;
        this.wordsTyped++;
        this.animateOrb('correct');
        this.nextWord();
        this.updateUI();
        this.calculateWPM();
    }
    
    incorrectWord() {
        this.lives--;
        this.animateOrb('incorrect');
        
        if (this.lives <= 0) {
            this.gameOver();
        } else {
            this.nextWord();
        }
        
        this.updateUI();
    }
    
    calculateWPM() {
        if (!this.startTime) return;
        
        const timeElapsed = (Date.now() - this.startTime) / (1000 * 60); // minutes
        const wpm = Math.round(this.wordsTyped / timeElapsed);
        
        if (wpm > this.bestWPM) {
            this.bestWPM = wpm;
        }
        
        document.getElementById('wpm').textContent = wpm;
    }
    
    animateOrb(type) {
        if (type === 'correct') {
            // Green flash
            this.orb.material.color.setHex(0x00ff00);
            this.orb.material.emissive.setHex(0x003300);
            
            setTimeout(() => {
                this.orb.material.color.setHex(0x00ffff);
                this.orb.material.emissive.setHex(0x001133);
            }, 200);
        } else {
            // Red flash
            this.orb.material.color.setHex(0xff0000);
            this.orb.material.emissive.setHex(0x330000);
            
            setTimeout(() => {
                this.orb.material.color.setHex(0x00ffff);
                this.orb.material.emissive.setHex(0x001133);
            }, 200);
        }
    }
    
    updateWordDisplay() {
        document.getElementById('current-word').textContent = this.currentWord;
        document.getElementById('typed-word').textContent = this.typedWord;
        
        // Color feedback
        const currentWordEl = document.getElementById('current-word');
        const typedWordEl = document.getElementById('typed-word');
        
        if (this.typedWord.length > 0) {
            if (this.currentWord.startsWith(this.typedWord)) {
                typedWordEl.style.color = '#4CAF50';
            } else {
                typedWordEl.style.color = '#ff4444';
            }
        }
    }
    
    updateUI() {
        document.getElementById('score').textContent = this.score;
        document.getElementById('lives').textContent = this.lives;
    }
    
    gameOver() {
        this.gameState = 'gameOver';
        
        document.getElementById('final-score').textContent = this.score;
        document.getElementById('final-wpm').textContent = this.bestWPM;
        document.getElementById('words-typed').textContent = this.wordsTyped;
        
        document.getElementById('game-over').classList.remove('hidden');
    }
    
    animate() {
        this.animationId = requestAnimationFrame(() => this.animate());
        
        this.time += 0.01;
        
        // Rotate orb
        if (this.orb) {
            this.orb.rotation.x += 0.005;
            this.orb.rotation.y += 0.01;
        }
        
        // Rotate wireframe
        if (this.wireframe) {
            this.wireframe.rotation.x += 0.003;
            this.wireframe.rotation.y += 0.007;
        }
        
        // Animate stars
        if (this.stars) {
            this.stars.rotation.y += 0.0005;
        }
        
        // Animate nebula
        if (this.nebula) {
            this.nebula.rotation.z += 0.001;
        }
        
        // Pulsing effect for orb
        if (this.orb && this.gameState === 'playing') {
            const scale = 1 + Math.sin(this.time * 2) * 0.05;
            this.orb.scale.setScalar(scale);
        }
        
        this.renderer.render(this.scene, this.camera);
    }
    
    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        
        if (this.renderer) {
            this.renderer.dispose();
        }
        
        // Clean up geometries and materials
        this.scene.traverse((object) => {
            if (object.geometry) {
                object.geometry.dispose();
            }
            if (object.material) {
                if (Array.isArray(object.material)) {
                    object.material.forEach(material => material.dispose());
                } else {
                    object.material.dispose();
                }
            }
        });
    }
}