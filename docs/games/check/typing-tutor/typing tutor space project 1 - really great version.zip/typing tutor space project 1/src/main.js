import * as THREE from 'three';
import { Game } from './game.js';

// Initialize the game when the page loads
window.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    const game = new Game(gameContainer);
    
    // Make game globally accessible for debugging
    window.game = game;
    
    console.log('AstroType game initialized successfully!');
});