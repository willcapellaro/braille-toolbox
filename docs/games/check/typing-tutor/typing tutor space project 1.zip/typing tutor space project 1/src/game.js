import * as THREE from 'three';
import { WordLibrary } from './userData.js';

export class Game {
    constructor(container, mode = 'beginner', userManager = null) {
        this.container = container;
        this.mode = mode;
        this.userManager = userManager;
        this.wordLibrary = new WordLibrary();
        
        // THREE.js objects
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.orb = null;
        this.stars = [];
        this.nebula = null;
        
        // Game state
        this.gameState = 'playing';
        this.isPaused = false;
        this.score = 0;
        this.lives = 3;
        this.currentWord = '';
        this.typedWord = '';
        this.wordsTyped = 0;
        this.startTime = null;
        this.bestWPM = 0;
        this.currentLevel = 3; // For beginner mode progression
        
        // Animation
        this.animationId = null;
        this.time = 0;
        
        this.init();
        this.setupEventListeners();
        this.startGame();
    }
    
    init() {
        this.setupScene();
        this.createOrb();
        this.createStarField();
        this.createNebula();
        this.setupLighting();
        this.animate();
    }
    
    setupScene() {
        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x000011);
        
        // Camera
        this.camera = new THREE.PerspectiveCamera(
            75,
            window.innerWidth / window.innerHeight,
            0.1,
            1000
        );
        this.camera.position.z = 5;
        
        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        this.container.appendChild(this.renderer.domElement);
        
        // Handle resize
        window.addEventListener('resize', () => this.onWindowResize());
    }
    
    createOrb() {
        const geometry = new THREE.IcosahedronGeometry(1, 1);
        
        // Create a custom material with animated properties
        const material = new THREE.MeshPhongMaterial({
            color: 0x00ffff,
            emissive: 0x001133,
            shininess: 100,
            transparent: true,
            opacity: 0.8
        });
        
        this.orb = new THREE.Mesh(geometry, material);
        this.scene.add(this.orb);
        
        // Add wireframe overlay
        const wireGeometry = new THREE.IcosahedronGeometry(1.01, 1);
        const wireMaterial = new THREE.MeshBasicMaterial({
            color: 0x00ffff,
            wireframe: true,
            transparent: true,
            opacity: 0.3
        });
        
        const wireframe = new THREE.Mesh(wireGeometry, wireMaterial);
        this.scene.add(wireframe);
        this.wireframe = wireframe;
    }
    
    createStarField() {
        const starGeometry = new THREE.BufferGeometry();
        const starMaterial = new THREE.PointsMaterial({
            color: 0xffffff,
            size: 2,
            transparent: true,
            opacity: 0.8
        });
        
        const starVertices = [];
        
        for (let i = 0; i < 10000; i++) {
            const x = (Math.random() - 0.5) * 2000;
            const y = (Math.random() - 0.5) * 2000;
            const z = (Math.random() - 0.5) * 2000;
            
            starVertices.push(x, y, z);
        }
        
        starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
        
        this.stars = new THREE.Points(starGeometry, starMaterial);
        this.scene.add(this.stars);
    }
    
    createNebula() {
        const nebulaGeometry = new THREE.PlaneGeometry(50, 50);
        const nebulaMaterial = new THREE.MeshBasicMaterial({
            color: 0x4b0082,
            transparent: true,
            opacity: 0.1,
            side: THREE.DoubleSide
        });
        
        this.nebula = new THREE.Mesh(nebulaGeometry, nebulaMaterial);
        this.nebula.position.z = -20;
        this.scene.add(this.nebula);
    }
    
    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.2);
        this.scene.add(ambientLight);
        
        // Point light
        const pointLight = new THREE.PointLight(0x00ffff, 1, 100);
        pointLight.position.set(10, 10, 10);
        this.scene.add(pointLight);
        
        // Directional light
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
        directionalLight.position.set(-1, 1, 1);
        this.scene.add(directionalLight);
    }
    
    setupEventListeners() {
        // Keyboard input
        this.keydownHandler = (event) => {
            if (this.gameState === 'playing' && !this.isPaused) {
                // Don't handle Escape - let UI manager handle it globally
                if (event.key !== 'Escape') {
                    this.handleKeyPress(event);
                }
            }
        };
        
        document.addEventListener('keydown', this.keydownHandler);
    }
    
    startGame() {
        this.gameState = 'playing';
        this.isPaused = false;
        this.score = 0;
        this.lives = 3;
        this.wordsTyped = 0;
        this.startTime = Date.now();
        this.bestWPM = 0;
        
        // Set current level based on user progress for beginner mode
        if (this.mode === 'beginner' && this.userManager) {
            const progress = this.userManager.getProgressForMode('beginner');
            this.currentLevel = progress ? progress.level : 3;
        }
        
        this.nextWord();
        this.updateUI();
    }
    
    restart() {
        this.startGame();
    }
    
    pause() {
        this.isPaused = true;
    }
    
    resume() {
        this.isPaused = false;
    }
    
    nextWord() {
        if (this.gameState !== 'playing') return;
        
        // Get word based on current mode and level
        this.currentWord = this.wordLibrary.getRandomWord(this.mode, this.currentLevel);
        this.typedWord = '';
        this.updateWordDisplay();
    }
    
    handleKeyPress(event) {
        if (event.key === 'Backspace') {
            this.typedWord = this.typedWord.slice(0, -1);
        } else if (event.key === 'Enter') {
            this.submitWord();
        } else if (event.key.length === 1 && /[a-zA-Z\s]/.test(event.key)) {
            this.typedWord += event.key.toLowerCase();
        }
        
        this.updateWordDisplay();
        
        // Auto-submit when word is complete
        if (this.typedWord === this.currentWord) {
            setTimeout(() => this.submitWord(), 100);
        }
    }
    
    submitWord() {
        if (this.typedWord === this.currentWord) {
            this.correctWord();
        } else {
            this.incorrectWord();
        }
    }
    
    correctWord() {
        this.score += this.currentWord.length * 10;
        this.wordsTyped++;
        this.animateOrb('correct');
        
        // Check for level progression - every 15 words at current level
        if (this.userManager) {
            const progress = this.userManager.getProgressForMode(this.mode);
            const wordsAtCurrentLevel = (progress ? progress.levelProgress : 0) + 1;
            const maxLevel = this.wordLibrary.getMaxLevel(this.mode);
            
            if (wordsAtCurrentLevel >= 15 && this.currentLevel < maxLevel) {
                this.currentLevel += 1;
                // Show progression notification
                this.showProgressNotification(`Level Up! ${this.currentLevel}-letter words unlocked!`);
            }
        }
        
        this.nextWord();
        this.updateUI();
        this.calculateWPM();
    }
    
    showProgressNotification(message) {
        // Create a temporary notification
        const notification = document.createElement('div');
        notification.className = 'progress-notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
            padding: 20px 30px;
            border-radius: 15px;
            font-size: 1.2em;
            font-weight: bold;
            z-index: 1000;
            box-shadow: 0 0 30px rgba(76, 175, 80, 0.5);
            animation: fadeInOut 3s ease-in-out;
        `;
        
        document.body.appendChild(notification);
        
        // Remove after animation
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    
    incorrectWord() {
        this.lives--;
        this.animateOrb('incorrect');
        
        if (this.lives <= 0) {
            this.gameOver();
        } else {
            this.nextWord();
        }
        
        this.updateUI();
    }
    
    calculateWPM() {
        if (!this.startTime) return;
        
        const timeElapsed = (Date.now() - this.startTime) / (1000 * 60); // minutes
        const wpm = Math.round(this.wordsTyped / timeElapsed);
        
        if (wpm > this.bestWPM) {
            this.bestWPM = wpm;
        }
        
        document.getElementById('wpm').textContent = wpm;
    }
    
    animateOrb(type) {
        if (type === 'correct') {
            // Green flash
            this.orb.material.color.setHex(0x00ff00);
            this.orb.material.emissive.setHex(0x003300);
            
            setTimeout(() => {
                this.orb.material.color.setHex(0x00ffff);
                this.orb.material.emissive.setHex(0x001133);
            }, 200);
        } else {
            // Red flash
            this.orb.material.color.setHex(0xff0000);
            this.orb.material.emissive.setHex(0x330000);
            
            setTimeout(() => {
                this.orb.material.color.setHex(0x00ffff);
                this.orb.material.emissive.setHex(0x001133);
            }, 200);
        }
    }
    
    updateWordDisplay() {
        document.getElementById('current-word').textContent = this.currentWord;
        document.getElementById('typed-word').textContent = this.typedWord;
        
        // Color feedback
        const currentWordEl = document.getElementById('current-word');
        const typedWordEl = document.getElementById('typed-word');
        
        if (this.typedWord.length > 0) {
            if (this.currentWord.startsWith(this.typedWord)) {
                typedWordEl.style.color = '#4CAF50';
            } else {
                typedWordEl.style.color = '#ff4444';
            }
        }
    }
    
    updateUI() {
        document.getElementById('score').textContent = this.score;
        document.getElementById('lives').textContent = this.lives;
    }
    
    gameOver() {
        this.gameState = 'gameOver';
        
        // Update UI
        document.getElementById('final-score').textContent = this.score;
        document.getElementById('final-wpm').textContent = this.bestWPM;
        document.getElementById('words-typed').textContent = this.wordsTyped;
        
        // Save user progress if user manager exists
        if (this.userManager) {
            const gameData = {
                mode: this.mode,
                score: this.score,
                wpm: this.bestWPM,
                wordsTyped: this.wordsTyped,
                level: this.currentLevel
            };
            
            this.userManager.updateUserStats(gameData);
        }
        
        document.getElementById('game-over').classList.remove('hidden');
    }
    
    animate() {
        this.animationId = requestAnimationFrame(() => this.animate());
        
        // Only update animations if not paused
        if (!this.isPaused) {
            this.time += 0.01;
            
            // Rotate orb
            if (this.orb) {
                this.orb.rotation.x += 0.005;
                this.orb.rotation.y += 0.01;
            }
            
            // Rotate wireframe
            if (this.wireframe) {
                this.wireframe.rotation.x += 0.003;
                this.wireframe.rotation.y += 0.007;
            }
            
            // Animate stars
            if (this.stars) {
                this.stars.rotation.y += 0.0005;
            }
            
            // Animate nebula
            if (this.nebula) {
                this.nebula.rotation.z += 0.001;
            }
            
            // Pulsing effect for orb
            if (this.orb && this.gameState === 'playing') {
                const scale = 1 + Math.sin(this.time * 2) * 0.05;
                this.orb.scale.setScalar(scale);
            }
        }
        
        this.renderer.render(this.scene, this.camera);
    }
    
    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    destroy() {
        // Cancel animation
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        
        // Remove event listeners
        if (this.keydownHandler) {
            document.removeEventListener('keydown', this.keydownHandler);
        }
        
        // Clean up THREE.js
        if (this.renderer) {
            if (this.container && this.renderer.domElement) {
                this.container.removeChild(this.renderer.domElement);
            }
            this.renderer.dispose();
        }
        
        // Clean up geometries and materials
        if (this.scene) {
            this.scene.traverse((object) => {
                if (object.geometry) {
                    object.geometry.dispose();
                }
                if (object.material) {
                    if (Array.isArray(object.material)) {
                        object.material.forEach(material => material.dispose());
                    } else {
                        object.material.dispose();
                    }
                }
            });
        }
    }
}