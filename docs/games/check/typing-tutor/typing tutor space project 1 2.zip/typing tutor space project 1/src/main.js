import * as THREE from 'three';
import { UIManager } from './uiManager.js';

// Initialize the game shell when the page loads
window.addEventListener('DOMContentLoaded', () => {
    const uiManager = new UIManager();
    
    // Make UI manager globally accessible for debugging
    window.uiManager = uiManager;
    
    console.log('AstroType game shell initialized successfully!');
});